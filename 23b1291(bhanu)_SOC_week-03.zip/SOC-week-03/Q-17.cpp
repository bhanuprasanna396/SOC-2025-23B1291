#include <iostream>
#include <string>
using namespace std;

int binaryToDecimal(const string& bin) {
    int result = 0;
    for (char bit : bin) {
        result = result * 2 + (bit - '0');
    }
    return result;
}

int main() {
    string x, y;
    cin >> x >> y;

    int a = binaryToDecimal(x);
    int b = binaryToDecimal(y);

    cout << a * b << endl;

    return 0;
}
