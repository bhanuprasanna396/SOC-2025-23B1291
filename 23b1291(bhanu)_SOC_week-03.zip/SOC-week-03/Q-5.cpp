#include <stdio.h>

int isPossible(int arr[], int n, int k, int maxPages) {
    int students = 1, currentSum = 0;

    for (int i = 0; i < n; ++i) {
        if (arr[i] > maxPages)
            return 0;

        if (currentSum + arr[i] > maxPages) {
            students++;
            currentSum = arr[i];
        } else {
            currentSum += arr[i];
        }
    }

    return students <= k;
}

int findPages(int arr[], int n, int k) {
    if (k > n) return -1;

    int low = arr[0], high = 0;
    for (int i = 0; i < n; ++i) {
        if (arr[i] > low) low = arr[i];
        high += arr[i];
    }

    int result = -1;

    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (isPossible(arr, n, k, mid)) {
            result = mid;
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }

    return result;
}
