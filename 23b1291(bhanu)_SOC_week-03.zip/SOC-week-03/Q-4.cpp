#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

int main() {
    int n;
    cin >> n;

    vector<tuple<int, int, int>> buildings(n);
    int maxRight = 0;

    for(int i = 0; i < n; ++i) {
        int l, r, h;
        cin >> l >> r >> h;
        buildings[i] = {l, r, h};
        maxRight = max(maxRight, r);
    }


    vector<int> height(maxRight + 1, 0);

    
    for(auto [l, r, h] : buildings) {
        for(int x = l; x < r; ++x) {
            height[x] = max(height[x], h);
        }
    }

    int area = 0;
    for(int x = 0; x < maxRight; ++x) {
        area += height[x];
    }

    cout << area << endl;
    return 0;
}
