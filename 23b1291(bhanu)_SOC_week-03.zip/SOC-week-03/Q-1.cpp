#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<pair<int, int>> intervals(n);

    for(int i = 0; i < n; ++i) {
        int start, end;
        cin >> start >> end;
        intervals[i] = {start, end};
    }

    
    sort(intervals.begin(), intervals.end());

    int total = 0;
    int curr_start = intervals[0].first;
    int curr_end = intervals[0].second;

    for(int i = 1; i < n; ++i) {
        int s = intervals[i].first;
        int e = intervals[i].second;

        if(s <= curr_end) {
            curr_end = max(curr_end, e); 
        } else {
            total += curr_end - curr_start;
            curr_start = s;
            curr_end = e;
        }
    }

    total += curr_end - curr_start; 

    cout << total << endl;
    return 0;
}
