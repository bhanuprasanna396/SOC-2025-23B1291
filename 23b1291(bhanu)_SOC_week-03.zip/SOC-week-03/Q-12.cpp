class Solution {
public:
    int count = 0;
    int result = -1;

    void reverseInorder(Node* root, int k) {
        if (!root || count >= k) return;

        reverseInorder(root->right, k);

        count++;
        if (count == k) {
            result = root->data;
            return;
        }

        reverseInorder(root->left, k);
    }

    int kthLargest(Node* root, int k) {
        reverseInorder(root, k);
        return result;
    }
};
