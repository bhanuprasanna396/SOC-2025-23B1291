class Solution {
public:
    Node* construct(vector<vector<int>>& grid) {
        return build(grid, 0, 0, grid.size());
    }

    Node* build(const vector<vector<int>>& grid, int x, int y, int size) {
        if (isUniform(grid, x, y, size)) {
            return new Node(grid[x][y], true);
        }

        int newSize = size / 2;
        Node* topLeft = build(grid, x, y, newSize);
        Node* topRight = build(grid, x, y + newSize, newSize);
        Node* bottomLeft = build(grid, x + newSize, y, newSize);
        Node* bottomRight = build(grid, x + newSize, y + newSize, newSize);

        Node* node = new Node(true, false);
        node->topLeft = topLeft;
        node->topRight = topRight;
        node->bottomLeft = bottomLeft;
        node->bottomRight = bottomRight;
        return node;
    }

    bool isUniform(const vector<vector<int>>& grid, int x, int y, int size) {
        int val = grid[x][y];
        for (int i = x; i < x + size; ++i) {
            for (int j = y; j < y + size; ++j) {
                if (grid[i][j] != val) return false;
            }
        }
        return true;
    }
};
