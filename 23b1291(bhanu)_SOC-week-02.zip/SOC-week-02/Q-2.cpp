class Solution {
public:
    vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
        vector<int>nums3;
       for(int i=0;i<nums1.size();++i){
        for(int j=0;j<nums2.size();++j){
            if(nums1[i]==nums2[j]){
            bool alreadyExists=false;
            for(int k=0;k<nums3.size();++k){
                if(nums3[k]==nums1[i]){
                    alreadyExists=true;
                    break;
                }
            }
            if(!alreadyExists) {
                    nums3.push_back(nums1[i]);
                }
                break;
            }

        }
       } 
       return nums3;
    }
};