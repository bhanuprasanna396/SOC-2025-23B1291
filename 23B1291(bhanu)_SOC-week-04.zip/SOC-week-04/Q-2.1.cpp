class Solution {
  public:
    void dfsRecursiveUtil(int node, vector<bool>& visited,
                          vector<vector<int>>& adj, vector<int>& result) {
        visited[node] = true;
        result.push_back(node);

        for (int i = 0; i < adj[node].size(); ++i) {
            int neighbor = adj[node][i];
            if (!visited[neighbor]) {
                dfsRecursiveUtil(neighbor, visited, adj, result);
            }
        }
    }

    vector<int> dfsRecursive(int V, vector<vector<int>>& adj) {
        vector<bool> visited(V, false);
        vector<int> result;
        dfsRecursiveUtil(0, visited, adj, result);
        return result;
    }
};

