class Solution {
  public:
    int minThrow(int N, int arr[]) {
        vector<int> board(31, -1); 

        
        for (int i = 0; i < 2 * N; i += 2) {
            board[arr[i]] = arr[i + 1];
        }

        vector<bool> visited(31, false);
        queue<pair<int, int>> q; 

        q.push(make_pair(1, 0));
        visited[1] = true;

        while (!q.empty()) {
            pair<int, int> front = q.front();
            q.pop();

            int cell = front.first;
            int throws = front.second;

            if (cell == 30) return throws;

            for (int dice = 1; dice <= 6; ++dice) {
                int next = cell + dice;
                if (next <= 30 && !visited[next]) {
                    visited[next] = true;
                    if (board[next] != -1)
                        next = board[next];
                    q.push(make_pair(next, throws + 1));
                }
            }
        }

        return -1; 
    }
};
