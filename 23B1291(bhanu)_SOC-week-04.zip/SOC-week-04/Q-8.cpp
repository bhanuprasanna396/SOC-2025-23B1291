class Solution {
  public:
    void dfs(vector<vector<int>>& image, int sr, int sc, int oldColor, int newColor) {
        int n = image.size();
        int m = image[0].size();

        if (sr < 0 || sr >= n || sc < 0 || sc >= m) return;
        if (image[sr][sc] != oldColor) return;

        image[sr][sc] = newColor;

        dfs(image, sr + 1, sc, oldColor, newColor);
        dfs(image, sr - 1, sc, oldColor, newColor);
        dfs(image, sr, sc + 1, oldColor, newColor);
        dfs(image, sr, sc - 1, oldColor, newColor);
    }

    vector<vector<int>> floodFill(vector<vector<int>>& image, int sr, int sc, int newColor) {
        int oldColor = image[sr][sc];
        if (oldColor != newColor) {
            dfs(image, sr, sc, oldColor, newColor);
        }
        return image;
    }
};
