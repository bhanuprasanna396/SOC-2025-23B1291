class Solution {
  public:
    vector<int> findOrder(int n, vector<vector<int>>& prerequisites) {
        vector<int> adj[n];
        vector<int> indegree(n, 0);

        // Build the graph
        for (auto& pre : prerequisites) {
            int u = pre[1], v = pre[0];
            adj[u].push_back(v);
            indegree[v]++;
        }

        queue<int> q;
        vector<int> order;

       
        for (int i = 0; i < n; ++i) {
            if (indegree[i] == 0) {
                q.push(i);
            }
        }

        while (!q.empty()) {
            int u = q.front(); q.pop();
            order.push_back(u);

            for (int v : adj[u]) {
                indegree[v]--;
                if (indegree[v] == 0) {
                    q.push(v);
                }
            }
        }

        if (order.size() == n)
            return order; 
        else
            return {}; 
    }
};
