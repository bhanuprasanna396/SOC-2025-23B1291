class Solution {
  public:
    vector<int> dfsIterative(int V, vector<vector<int>>& adj) {
        vector<bool> visited(V, false);
        vector<int> result;
        stack<int> st;

        st.push(0);

        while (!st.empty()) {
            int node = st.top(); st.pop();

            if (!visited[node]) {
                visited[node] = true;
                result.push_back(node);

                
                for (int i = adj[node].size() - 1; i >= 0; --i) {
                    int neighbor = adj[node][i];
                    if (!visited[neighbor]) {
                        st.push(neighbor);
                    }
                }
            }
        }

        return result;
    }
};
