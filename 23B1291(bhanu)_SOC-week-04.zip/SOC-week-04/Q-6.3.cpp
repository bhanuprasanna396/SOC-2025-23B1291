class Solution {
  public:
    bool dfs(int x, int y, int fromX, int fromY, vector<vector<char>>& grid,
             vector<vector<bool>>& visited, char target) {
        int n = grid.size();
        int m = grid[0].size();
        visited[x][y] = true;

        int dx[] = {-1, 1, 0, 0}; 
        int dy[] = {0, 0, -1, 1}; 

        for (int d = 0; d < 4; ++d) {
            int nx = x + dx[d];
            int ny = y + dy[d];

            
            if (nx < 0 || ny < 0 || nx >= n || ny >= m) continue;

           
            if (nx == fromX && ny == fromY) continue;

           
            if (grid[nx][ny] != target) continue;

            if (visited[nx][ny]) return true;

         
            if (dfs(nx, ny, x, y, grid, visited, target)) return true;
        }

        return false;
    }

    bool containsCycle(vector<vector<char>>& grid) {
        int n = grid.size();
        int m = grid[0].size();
        vector<vector<bool>> visited(n, vector<bool>(m, false));

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                if (!visited[i][j]) {
                    if (dfs(i, j, -1, -1, grid, visited, grid[i][j]))
                        return true;
                }
            }
        }

        return false;
    }
};
