class Solution {
  public:
    vector<vector<int>> buildGraph(int V, vector<vector<int>>& edges) {
        vector<vector<int>> adj(V);

        for (int i = 0; i < edges.size(); ++i) {
            int u = edges[i][0];
            int v = edges[i][1];

            adj[u].push_back(v);
            adj[v].push_back(u); 
        }

        return adj;
    }
};
