class Solution {
  public:
    vector<int> bfsIterative(int V, vector<vector<int>>& adj) {
        vector<bool> visited(V, false);
        vector<int> result;
        queue<int> q;

        visited[0] = true;
        q.push(0);

        while (!q.empty()) {
            int node = q.front(); q.pop();
            result.push_back(node);

            for (int i = 0; i < adj[node].size(); ++i) {
                int neighbor = adj[node][i];
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }

        return result;
    }
};