class Solution {
  public:
    void bfsHelper(queue<int>& q, vector<bool>& visited,
                   vector<vector<int>>& adj, vector<int>& result) {
        if (q.empty()) return;

        int node = q.front(); q.pop();
        result.push_back(node);

        for (int i = 0; i < adj[node].size(); ++i) {
            int neighbor = adj[node][i];
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }

        bfsHelper(q, visited, adj, result);
    }

    vector<int> bfsRecursive(int V, vector<vector<int>>& adj) {
        vector<bool> visited(V, false);
        vector<int> result;
        queue<int> q;

        visited[0] = true;
        q.push(0);

        bfsHelper(q, visited, adj, result);
        return result;
    }
};

