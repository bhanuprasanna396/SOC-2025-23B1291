class Solution {
  public:
    int dfs(int node, int destination, vector<int> adj[]) {
        if (node == destination) return 1;

        int count = 0;
        for (int neighbor : adj[node]) {
            count += dfs(neighbor, destination, adj);
        }
        return count;
    }

    int countPaths(int V, vector<int> adj[], int source, int destination) {
        return dfs(source, destination, adj);
    }
};
