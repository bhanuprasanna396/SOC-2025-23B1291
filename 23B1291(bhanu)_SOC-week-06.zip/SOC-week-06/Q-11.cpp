class Solution {
  public:
    int maxStop(int n, int m, vector<vector<int>> &trains) {
        
        vector<vector<pair<int, int>>> platforms(n + 1);

        for (int i = 0; i < m; i++) {
            int arr = trains[i][0];
            int dep = trains[i][1];
            int plt = trains[i][2];
            platforms[plt].push_back({dep, arr}); 
        }

        int count = 0;

       
        for (int i = 1; i <= n; i++) {
            sort(platforms[i].begin(), platforms[i].end());

            int lastDep = -1;
            for (auto &train : platforms[i]) {
                int dep = train.first;
                int arr = train.second;

                if (arr > lastDep) {
                    count++;
                    lastDep = dep;
                }
            }
        }

        return count;
    }
};
