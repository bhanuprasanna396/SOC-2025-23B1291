class Solution {
  public:
    vector<int> JobScheduling(vector<int>& deadline, vector<int>& profit) {
        int n = deadline.size();
        vector<pair<int, int>> jobs;

        for (int i = 0; i < n; i++) {
            jobs.push_back({profit[i], deadline[i]});
        }

        sort(jobs.rbegin(), jobs.rend());

        int maxDeadline = *max_element(deadline.begin(), deadline.end());
        vector<int> slot(maxDeadline + 1, -1);  

        int count = 0, totalProfit = 0;

        for (auto& job : jobs) {
            int d = job.second;
            int p = job.first;

            
            for (int j = d; j >= 1; j--) {
                if (slot[j] == -1) {
                    slot[j] = p;  
                    count++;
                    totalProfit += p;
                    break;
                }
            }
        }

        return {count, totalProfit};
    }
};
