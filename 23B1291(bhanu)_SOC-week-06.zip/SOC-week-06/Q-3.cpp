class Solution {
  public:
    struct Node {
        char ch;
        int freq;
        Node* left;
        Node* right;

        Node(char c, int f) {
            ch = c;
            freq = f;
            left = right = nullptr;
        }
    };

    struct cmp {
        bool operator()(pair<int, int>& a, pair<int, int>& b) {
            if (a.first == b.first) return a.second > b.second; // tie-break by position
            return a.first > b.first;
        }
    };

    vector<string> ans;

    void preorder(Node* root, string code) {
        if (!root) return;
        if (!root->left && !root->right) {
            ans.push_back(code);
        }
        preorder(root->left, code + "0");
        preorder(root->right, code + "1");
    }

    vector<string> huffmanCodes(string S, vector<int> f, int N) {
        
        priority_queue<pair<int, int>, vector<pair<int, int>>, cmp> pq;
        vector<Node*> nodes(N);

        for (int i = 0; i < N; i++) {
            pq.push({f[i], i});
            nodes[i] = new Node(S[i], f[i]);
        }

        int nextIndex = N;
        while (pq.size() > 1) {
            auto a = pq.top(); pq.pop();
            auto b = pq.top(); pq.pop();

            Node* left = nodes[a.second];
            Node* right = nodes[b.second];

            Node* parent = new Node('$', a.first + b.first);
            parent->left = left;
            parent->right = right;

            nodes.push_back(parent);
            pq.push({a.first + b.first, nextIndex++});
        }

        Node* root = nodes[pq.top().second];
        preorder(root, "");
        return ans;
    }
};
