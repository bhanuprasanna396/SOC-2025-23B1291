class Solution {
  public:
    int minSubset(vector<int>& arr) {
        int total = accumulate(arr.begin(), arr.end(), 0);
        sort(arr.rbegin(), arr.rend()); 

        int selectedSum = 0;
        int count = 0;

        for (int x : arr) {
            selectedSum += x;
            count++;
            if (selectedSum > total - selectedSum) {
                break;
            }
        }
        return count;
    }
};
