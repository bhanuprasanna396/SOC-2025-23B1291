class Solution {
  public:
    int minCostToOneElement(vector<int>& arr) {
        int n = arr.size();
        if (n <= 1) return 0;

        
        sort(arr.begin(), arr.end());

        int cost = 0;
        for (int i = 0; i < n - 1; i++) {
            cost += arr[i];
        }

        return cost;
    }
};
