class Solution {
  public:
    vector<vector<int>> mergeIntervals(vector<vector<int>>& arr) {
        int n = arr.size();
        if (n == 0) return {};

        
        sort(arr.begin(), arr.end());

        vector<vector<int>> merged;
        merged.push_back(arr[0]);

        for (int i = 1; i < n; i++) {
         
            vector<int>& last = merged.back();

            if (arr[i][0] <= last[1]) {
                last[1] = max(last[1], arr[i][1]); 
            } else {
                merged.push_back(arr[i]); 
            }
        }

        return merged;
    }
};
