class Solution {
  public:
    vector<int> candyStore(int candies[], int N, int K) {
        sort(candies, candies + N);  

        int minCost = 0, maxCost = 0;

        
        int i = 0, j = N - 1;
        while (i <= j) {
            minCost += candies[i];
            i++;
            j -= K;  
        }


        i = 0, j = N - 1;
        while (i <= j) {
            maxCost += candies[j];
            j--;
            i += K;  
        }

        return {minCost, maxCost};
    }
};
