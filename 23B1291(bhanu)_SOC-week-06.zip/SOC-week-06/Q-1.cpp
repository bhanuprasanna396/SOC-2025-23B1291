// class implemented
/*
struct Item{
    int value;
    int weight;
};
*/

class Solution {
  public:
    double fractionalKnapsack(vector<int>& val, vector<int>& wt, int capacity) {
        int n = val.size();
        vector<pair<double, int>> ratioIndex;

        
        for (int i = 0; i < n; i++) {
            double ratio = (double)val[i] / wt[i];
            ratioIndex.push_back({ratio, i});
        }

        
        sort(ratioIndex.rbegin(), ratioIndex.rend());

        double totalValue = 0.0;

        for (int i = 0; i < n && capacity > 0; i++) {
            int idx = ratioIndex[i].second;

            if (wt[idx] <= capacity) {
                totalValue += val[idx];
                capacity -= wt[idx];
            } else {
                totalValue += ratioIndex[i].first * capacity;
                break;
            }
        }

        return totalValue;
    }
};

