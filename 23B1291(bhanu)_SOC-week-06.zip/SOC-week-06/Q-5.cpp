class Solution {
  public:
    int maxCircularSum(vector<int>& arr) {
        sort(arr.begin(), arr.end());
        int n = arr.size();

        vector<int> temp(n);
        int i = 0, j = n - 1, idx = 0;

        
        while (i <= j) {
            if (i != j) {
                temp[idx++] = arr[i++];
                temp[idx++] = arr[j--];
            } else {
                temp[idx++] = arr[i++];
            }
        }

       
        int sum = 0;
        for (int k = 0; k < n; k++) {
            sum += abs(temp[k] - temp[(k + 1) % n]);
        }

        return sum;
    }
};
