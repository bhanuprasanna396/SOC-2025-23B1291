class TrieNode {
public:
    unordered_map<char, TrieNode*> children;
    bool isEnd = false;
    string word;
};

class Solution {
    TrieNode* root = new TrieNode();
    int dx[8] = {-1,-1,-1, 0, 0, 1,1,1};
    int dy[8] = {-1, 0, 1,-1, 1,-1,0,1};

    void insert(string& word) {
        TrieNode* node = root;
        for (char ch : word) {
            if (!node->children.count(ch))
                node->children[ch] = new TrieNode();
            node = node->children[ch];
        }
        node->isEnd = true;
        node->word = word;
    }

    void dfs(int i, int j, vector<vector<char>>& board, TrieNode* node, vector<vector<bool>>& vis, unordered_set<string>& res) {
        char ch = board[i][j];
        if (!node->children.count(ch)) return;
        node = node->children[ch];

        if (node->isEnd) res.insert(node->word);

        vis[i][j] = true;
        for (int d = 0; d < 8; ++d) {
            int ni = i + dx[d], nj = j + dy[d];
            if (ni >= 0 && nj >= 0 && ni < board.size() && nj < board[0].size() && !vis[ni][nj])
                dfs(ni, nj, board, node, vis, res);
        }
        vis[i][j] = false;
    }

public:
    vector<string> openGates(int n, vector<string>& gate_names, vector<vector<char>>& board) {
        // Build Trie from unique gate names
        unordered_set<string> uniqueWords(gate_names.begin(), gate_names.end());
        for (string word : uniqueWords)
            insert(word);

        unordered_set<string> found;
        int R = board.size(), C = board[0].size();
        vector<vector<bool>> vis(R, vector<bool>(C, false));

        for (int i = 0; i < R; ++i) {
            for (int j = 0; j < C; ++j) {
                dfs(i, j, board, root, vis, found);
            }
        }

        vector<string> ans(found.begin(), found.end());
        sort(ans.begin(), ans.end());
        return ans;
    }
};
