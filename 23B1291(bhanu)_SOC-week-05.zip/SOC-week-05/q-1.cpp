class Solution {
public:
    vector<int> dijkstra(int V, vector<vector<int>> adj[], int src) {
        vector<int> dist(V, INT_MAX);
        dist[src] = 0;
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
        pq.push({0, src});

        while (!pq.empty()) {
            int d = pq.top().first, u = pq.top().second;
            pq.pop();
            for (auto &edge : adj[u]) {
                int v = edge[0], w = edge[1];
                if (dist[v] > d + w) {
                    dist[v] = d + w;
                    pq.push({dist[v], v});
                }
            }
        }

        return dist;
    }
};
