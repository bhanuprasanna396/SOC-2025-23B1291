class DSU {
    vector<int> parent, rank;
public:
    DSU(int n) {
        parent.resize(n + 1);
        rank.resize(n + 1, 0);
        iota(parent.begin(), parent.end(), 0);
    }
    int find(int x) {
        if (x != parent[x])
            parent[x] = find(parent[x]);
        return parent[x];
    }
    bool unite(int x, int y) {
        int xr = find(x), yr = find(y);
        if (xr == yr) return false;
        if (rank[xr] < rank[yr]) parent[xr] = yr;
        else if (rank[xr] > rank[yr]) parent[yr] = xr;
        else parent[yr] = xr, rank[xr]++;
        return true;
    }
};

int minimumRepairCost(vector<vector<int>> &edges) {
    int maxNode = 0;
    for (auto &e : edges)
        maxNode = max({maxNode, e[0], e[1]});

    DSU dsu(maxNode);
    sort(edges.begin(), edges.end(), [](auto &a, auto &b) {
        return a[2] < b[2];
    });

    int cost = 0, count = 0;
    for (auto &e : edges) {
        if (dsu.unite(e[0], e[1])) {
            cost += e[2];
            count++;
            if (count == maxNode - 1) break;
        }
    }
    return (count == maxNode - 1) ? cost : -1; // -1 if disconnected
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int m;
        cin >> m;
        vector<vector<int>> edges(m, vector<int>(3));
        for (int i = 0; i < m; ++i)
            cin >> edges[i][0] >> edges[i][1] >> edges[i][2];

        cout << minimumRepairCost(edges) << endl;
    }
    return 0;
}