class Solution {
private:
    int timer;
    vector<vector<int>> sccs;
    stack<int> st;
    vector<int> disc, low;
    vector<bool> inStack;

    void dfs(int u, vector<int> adj[]) {
        disc[u] = low[u] = timer++;
        st.push(u);
        inStack[u] = true;

        for (int v : adj[u]) {
            if (disc[v] == -1) {
                dfs(v, adj);
                low[u] = min(low[u], low[v]);
            } else if (inStack[v]) {
                low[u] = min(low[u], disc[v]);
            }
        }

        if (disc[u] == low[u]) {
            vector<int> scc;
            int v;
            do {
                v = st.top(); st.pop();
                inStack[v] = false;
                scc.push_back(v);
            } while (u != v);
            sort(scc.begin(), scc.end());
            sccs.push_back(scc);
        }
    }

public:
    vector<vector<int>> tarjans(int V, vector<int> adj[]) {
        disc.assign(V, -1);
        low.assign(V, -1);
        inStack.assign(V, false);
        timer = 0;

        for (int i = 0; i < V; ++i) {
            if (disc[i] == -1)
                dfs(i, adj);
        }

        sort(sccs.begin(), sccs.end());
        return sccs;
    }
};
