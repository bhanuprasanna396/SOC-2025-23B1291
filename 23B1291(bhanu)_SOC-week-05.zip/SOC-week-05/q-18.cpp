class Solution {
public:
    int wordBreak(int n, string A, vector<string> &B) {
        unordered_set<string> dict(B.begin(), B.end());
        int len = A.length();
        vector<bool> dp(len + 1, false);
        dp[0] = true;

        for (int i = 1; i <= len; ++i) {
            for (int j = 0; j < i; ++j) {
                if (dp[j] && dict.count(A.substr(j, i - j))) {
                    dp[i] = true;
                    break;
                }
            }
        }

        return dp[len];
    }
};
