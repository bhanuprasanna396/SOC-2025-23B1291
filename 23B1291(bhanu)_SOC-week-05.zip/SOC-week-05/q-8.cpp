class TrieNode {
public:
    TrieNode* children[26];
    bool isEnd;

    TrieNode() {
        isEnd = false;
        fill(begin(children), end(children), nullptr);
    }
};

class WordDictionary {
private:
    TrieNode* root;

    bool dfs(string& word, int i, TrieNode* node) {
        if (i == word.size()) return node->isEnd;

        if (word[i] == '.') {
            for (int j = 0; j < 26; ++j) {
                if (node->children[j] && dfs(word, i + 1, node->children[j]))
                    return true;
            }
            return false;
        } else {
            int idx = word[i] - 'a';
            return node->children[idx] && dfs(word, i + 1, node->children[idx]);
        }
    }

public:
    WordDictionary() {
        root = new TrieNode();
    }

    void addWord(string word) {
        TrieNode* node = root;
        for (char ch : word) {
            int idx = ch - 'a';
            if (!node->children[idx])
                node->children[idx] = new TrieNode();
            node = node->children[idx];
        }
        node->isEnd = true;
    }

    bool search(string word) {
        return dfs(word, 0, root);
    }
};
