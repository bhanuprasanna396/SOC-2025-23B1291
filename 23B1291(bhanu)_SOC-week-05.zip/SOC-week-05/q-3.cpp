class Solution {
    void topo(int node, vector<pair<int, int>> adj[], vector<bool> &vis, stack<int> &st) {
        vis[node] = true;
        for (auto &edge : adj[node]) {
            if (!vis[edge.first]) topo(edge.first, adj, vis, st);
        }
        st.push(node);
    }

public:
    vector<int> shortestPath(int V, int E, vector<vector<int>> &edges) {
        vector<pair<int, int>> adj[V];
        for (auto &e : edges)
            adj[e[0]].push_back({e[1], e[2]});

        stack<int> st;
        vector<bool> vis(V, false);
        for (int i = 0; i < V; ++i)
            if (!vis[i]) topo(i, adj, vis, st);

        vector<int> dist(V, -1);
        dist[0] = 0;

        while (!st.empty()) {
            int u = st.top(); st.pop();
            if (dist[u] != -1) {
                for (auto &e : adj[u]) {
                    int v = e.first, w = e.second;
                    if (dist[v] == -1 || dist[v] > dist[u] + w)
                        dist[v] = dist[u] + w;
                }
            }
        }

        return dist;
    }
};
