class Solution {
public:
    int spanningTree(int V, vector<vector<int>> adj[]) {
        vector<bool> inMST(V, false);
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;

        pq.push({0, 0}); // {weight, node}
        int mst_weight = 0;

        while (!pq.empty()) {
            auto [wt, u] = pq.top(); pq.pop();
            if (inMST[u]) continue;
            inMST[u] = true;
            mst_weight += wt;

            for (auto &edge : adj[u]) {
                int v = edge[0], w = edge[1];
                if (!inMST[v]) {
                    pq.push({w, v});
                }
            }
        }

        return mst_weight;
    }
};
