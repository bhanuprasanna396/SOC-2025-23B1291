class Solution {
    int timer;
    bool isBridgeEdge;

    void dfs(int u, int parent, vector<int> adj[], vector<int>& tin, vector<int>& low, vector<bool>& visited, int c, int d) {
        visited[u] = true;
        tin[u] = low[u] = ++timer;

        for (int v : adj[u]) {
            if (v == parent) continue;
            if (!visited[v]) {
                dfs(v, u, adj, tin, low, visited, c, d);
                low[u] = min(low[u], low[v]);

                if (low[v] > tin[u]) {
                    // (u, v) is a bridge
                    if ((u == c && v == d) || (u == d && v == c))
                        isBridgeEdge = true;
                }
            } else {
                low[u] = min(low[u], tin[v]);
            }
        }
    }

public:
    bool isBridge(int V, vector<vector<int>>& edges, int c, int d) {
        vector<int> adj[V];
        for (auto& edge : edges) {
            adj[edge[0]].push_back(edge[1]);
            adj[edge[1]].push_back(edge[0]);
        }

        vector<int> tin(V, -1), low(V, -1);
        vector<bool> visited(V, false);
        timer = 0;
        isBridgeEdge = false;

        for (int i = 0; i < V; ++i)
            if (!visited[i])
                dfs(i, -1, adj, tin, low, visited, c, d);

        return isBridgeEdge;
    }
};
