class DisjointSet {
    vector<int> parent, rank;
public:
    DisjointSet(int n) {
        parent.resize(n);
        rank.resize(n, 0);
        iota(parent.begin(), parent.end(), 0);
    }

    int find(int x) {
        if (parent[x] != x)
            parent[x] = find(parent[x]);
        return parent[x];
    }

    bool unite(int x, int y) {
        int xr = find(x), yr = find(y);
        if (xr == yr) return false;
        if (rank[xr] < rank[yr]) parent[xr] = yr;
        else if (rank[xr] > rank[yr]) parent[yr] = xr;
        else parent[yr] = xr, rank[xr]++;
        return true;
    }
};

class Solution {
public:
    int spanningTree(int V, vector<vector<int>> edges) {
        sort(edges.begin(), edges.end(), [](auto &a, auto &b) {
            return a[2] < b[2];
        });

        DisjointSet ds(V);
        int weight = 0;

        for (auto &e : edges) {
            if (ds.unite(e[0], e[1]))
                weight += e[2];
        }

        return weight;
    }
};
