class Solution {
  public:
    int minCost(vector<int>& height) {
        int prev = 0, prev2 = 0, n = height.size();

        for (int i = 1; i < n; ++i) {
            int jump1 = prev + abs(height[i] - height[i - 1]);
            int jump2 = (i > 1) ? prev2 + abs(height[i] - height[i - 2]) : INT_MAX;
            int curr = min(jump1, jump2);
            prev2 = prev;
            prev = curr;
        }

        return prev;
    }
};
