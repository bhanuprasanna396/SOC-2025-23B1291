class Solution {
  public:
    int lis(int n, vector<int>& arr) {
        vector<int> dp(n, 1);
        int lis = 1;

        for (int i = 1; i < n; ++i) {
            for (int j = 0; j < i; ++j) {
                if (arr[i] > arr[j]) {
                    dp[i] = max(dp[i], dp[j] + 1);
                }
            }
            lis = max(lis, dp[i]);
        }

        return lis;
    }
};
