// User function Template for C++
class Solution {
  public:
    int nthFibonacci(int n) {
        const int MOD = 1000000007;
        if (n == 0) return 0;
        int a = 0, b = 1;
        for (int i = 2; i <= n; ++i) {
            int temp = (a + b) % MOD;
            a = b;
            b = temp;
        }
        return b;
    }
};
