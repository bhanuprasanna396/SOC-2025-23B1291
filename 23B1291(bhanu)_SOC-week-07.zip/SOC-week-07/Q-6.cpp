class Solution {
  public:
    int FindMaxSum(vector<int>& arr) {
        int n = arr.size();
        if (n == 0) return 0;
        if (n == 1) return arr[0];

        int prev2 = arr[0];
        int prev = max(arr[0], arr[1]);

        for (int i = 2; i < n; ++i) {
            int curr = max(prev, prev2 + arr[i]);
            prev2 = prev;
            prev = curr;
        }

        return prev;
    }
};
