class Solution {
public:
    int maxArea(vector<int>& height) {
        int* left = &height[0];
        int* right = &height[0] + height.size() - 1;
        int maxWater = 0;

        while (left < right) {
            int width = right - left;
            int minHeight = min(*left, *right);
            maxWater = max(maxWater, width * minHeight);

            if (*left < *right)
                ++left;
            else
                --right;
        }

        return maxWater;
        
    }
};