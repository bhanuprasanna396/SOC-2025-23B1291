class Solution {
public:
    int minSubArrayLen(int target, vector<int>& nums) {
        int count=0;
        for(int i=0;i<nums.size();++i){
            for(int j=i+1;j<nums.size();++j){
                if(nums[j]+nums[i]>=target)
                

            }
        }
        
    }
};