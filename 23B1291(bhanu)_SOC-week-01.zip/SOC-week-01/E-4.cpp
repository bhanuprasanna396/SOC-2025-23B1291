class Solution {
public:
    vector<int> twoSum(vector<int>& numbers, int target) {
        int* left = &numbers[0];
        int* right = &numbers[numbers.size() - 1];

        while (left < right) {
            int sum = *left + *right;

            if (sum == target) {
                return {int(left - &numbers[0] + 1), int(right - &numbers[0] + 1)};
            } else if (sum < target) {
                ++left;
            } else {
                --right;
            }
        }

        return {};
        
    }
};