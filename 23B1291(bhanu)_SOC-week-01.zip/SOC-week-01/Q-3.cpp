class Solution {
public:
    int majorityElement(vector<int>& nums) {
        int vote = 0, count = 0;
        for (int num : nums) {
            if (count == 0) vote = num;
            count += (num == vote) ? 1 : -1;
        }
        return vote;
        
    }
    
};